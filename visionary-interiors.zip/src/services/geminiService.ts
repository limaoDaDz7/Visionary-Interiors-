import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface Message {
  role: "user" | "model";
  text: string;
}

export interface ShoppableItem {
  name: string;
  price: string;
  image: string;
  link: string;
}

export async function chatWithDesigner(
  prompt: string,
  history: Message[],
  imageData?: string
) {
  const contents = history.map((msg) => ({
    role: msg.role,
    parts: [{ text: msg.text }],
  }));

  const parts: any[] = [{ text: prompt }];
  if (imageData) {
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: imageData.split(",")[1],
      },
    });
  }

  contents.push({
    role: "user",
    parts: parts,
  });

  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: contents,
    config: {
      systemInstruction: `You are a world-class Interior Design Consultant named "Visionary". 
      Your goal is to help users reimagine their spaces. 
      When a user uploads a photo, analyze it and provide expert advice.
      When they ask for refinements, be specific.
      Always try to include "shoppable links" in your response for items you suggest. 
      Format these links as [Item Name](https://www.google.com/search?q=buy+item+name).
      Be encouraging, sophisticated, and professional.`,
    },
  });

  return response.text;
}

export async function detectRoomType(imageData: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageData.split(",")[1],
            },
          },
          { text: "What type of room is this? (e.g., Living Room, Bedroom, Kitchen, Office, Bathroom). Return only the room type name." },
        ],
      },
    });
    return response.text.trim() || "Room";
  } catch (error) {
    return "Room";
  }
}

export async function getShoppableItems(style: string, roomType: string): Promise<ShoppableItem[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate 4 furniture or decor items for a ${roomType} in ${style} style. 
      Return a JSON array of objects with keys: name, price (e.g. $120), image (use a descriptive picsum url like https://picsum.photos/seed/itemname/400/400), and link (google search link).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              price: { type: Type.STRING },
              image: { type: Type.STRING },
              link: { type: Type.STRING },
            },
            required: ["name", "price", "image", "link"],
          },
        },
      },
    });
    return JSON.parse(response.text);
  } catch (error) {
    return [];
  }
}

export async function reimagineRoom(
  imageData: string,
  style: string,
  mood: string = "Balanced"
): Promise<string | null> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageData.split(",")[1],
            },
          },
          {
            text: `Reimagine this room in ${style} style with a ${mood} mood. Maintain the basic layout and structure but completely transform the furniture, colors, and decor to match the ${style} aesthetic perfectly. The output should be a high-quality, photorealistic interior design visualization. Ensure lighting is optimized for the ${mood} atmosphere.`,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error reimagining room:", error);
    return null;
  }
}
